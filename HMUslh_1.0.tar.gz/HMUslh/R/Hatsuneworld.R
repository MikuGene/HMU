## source("https://bioconductor.org/biocLite.R")
## 8a03a29901b31176e32928321b1349e6 library(openssl)
## source("E:/Shengxin/Rword/Hatsuneworld.R")
## options(scipen = 6)  ## keep decimal point.
## tmp=strsplit(rownames(dd),'\\|')
## tmp=sapply(tmp,function(x)x[[1]]) ## take up the one.
## tmp.vv=which(nchar(tmp)>1) ## see each char number.
## setequal(x1,x2) Interpret same.
## CESC_RNA<-CESC_RNA[!duplicated(CESC_RNA[,1]),] 
## na.omit(t())
## read.csv(....,skip = 1,...)
## awk '{if(NR%4 == 1){print ">" substr($0, 2)}}{if(NR%4 == 2){print}}' FF13-7.fq > FF13-7.fa ##
## library(devtools)
## install_github("vqv/ggbiplot")
## library("ggbiplot")  printFlush()
library("dplyr")
library("sva")
library("pheatmap")
library("pROC")
library("survival")
library("survminer")
gc()
## 8a03a29901b31176e32928321b1349e6
print("Welcome to Hatsune world !!! Everything is going on. Any questions, please Wechat Hatsune miku 18746004617; QQ 2743623823.")
## 8a03a29901b31176e32928321b1349e6
remRow <- function(x,Rem=0.1){
  a <- as.matrix(x)
  a <- t(apply(a,1,as.numeric))
  r <-as.numeric(apply(a,1,function(i) sum(i == 0)))
  remove <- which(r>dim(a)[2]*Rem)
  rm(r)
  Frame <- x[-remove,]
  rm(remove)
  gc()
  return(Frame)}
## 8a03a29901b31176e32928321b1349e6
canFil<-function(x,save = F){
  if(sum(duplicated(substr(colnames(x),1,12)))>0)
  {x<-x[,colnames(x) %in% sort(colnames(x))[!duplicated(substr(sort(colnames(x)),1,12))]]}
  Can<-x[,which(substr(colnames(x),14,14)=="0")]
  Nor<-x[,which(substr(colnames(x),14,14)=="1")]
  colnames(Can) <- gsub("\\.","-",substr(toupper(colnames(Can)),1,12))
  if(save){
    print("Please input the name you want to save. Such as LGG_FPKMUQ_mRNA")
    name<-scan(what = "character")
    write.csv(Can,paste(name,"Can.csv",sep = "_"))
    write.csv(Nor,paste(name,"Nor.csv",sep = "_"))}
  rm(Nor)
  gc()
  return(Can)}
## 8a03a29901b31176e32928321b1349e6
WGCNA_CliCustom<- function(x,y,IDname = "A0_Samples",Need_t = T,save = F){
  options(stringsAsFactors = F)
  if(Need_t){x <- as.data.frame(t(x))}
  colnames(y)<-gsub("\\.","-",substr(toupper(colnames(y)),1,12))
  x[IDname,]<-gsub("\\.","-",substr(toupper(x[IDname,]),1,12))
  ComID<-intersect(colnames(y),x[IDname,])
  FPKMRows<-match(ComID,colnames(y))
  FPKMSim<-y[,FPKMRows]
  traitRows<-match(ComID,x[IDname,])
  simpleCli<-x[-which(rownames(x)==IDname),traitRows]
  colnames(simpleCli) = x[which(rownames(x)==IDname),traitRows]
  rownames(simpleCli) = rownames(x)[-which(rownames(x)==IDname)]
  rm(ComID,FPKMRows,traitRows)
  if(save){
  print("Now please write WGCNA name. Such as: LGG_FPKMUQ_mRNA")
  name<-scan(what = "character")
  write.csv(simpleCli,paste(name,"WGCNA_clinical.csv",sep = "_"))
  write.csv(FPKMSim,paste(name,"WGCNA_FPKM.csv",sep = "_"))
  rm(name)}
  gc()
  a<-list(simpleCli,FPKMSim)
  rm(simpleCli,FPKMSim)
  gc()
  return(a)}
## 8a03a29901b31176e32928321b1349e6
WGCNA_TOMmap<-function(x,nCPU = 5,Cutsample = T,nGene = 10,mGene = 12,minMD = 30,Map = F,custom = F){
  library(WGCNA)
  enableWGCNAThreads(nThreads = nCPU)
  if(!custom){
  if(is.numeric(nGene))
  {FPKM<-t(x[[2]][order(apply(x[[2]],1,mad),decreasing = T)[1:(nGene*1000)],])}
  if(!is.numeric(nGene))
  {FPKM<-t(x[[2]][apply(x[[2]],1,mad)>0,])}}
  if(custom){FPKM <- t(x)}
  gsg<-goodSamplesGenes(FPKM, verbose = 3)
  FPKM<-FPKM[gsg$goodSamples, gsg$goodGenes]
  rm(gsg)
  gc()
  if(Cutsample){
    sampleTree<-hclust(dist(FPKM), method = "average")
    par(cex = 0.6)
    par(mar = c(0,4,2,0))
    plot(sampleTree,main = "Sample clustering to detect outliers",sub="",xlab="",cex.lab = 1.5,cex.axis = 1.5,cex.main = 2)
    print("Welcome to Hatsune world. Now let`s cut the samples")
    okline<-scan()
    abline(h = okline, col = "red")
    print("Can it appropriate?")
    ok<-scan(what = "character")
    while(!ok=="yes")
    {print("Please try again")
      okline<-scan()
      abline(h = okline, col = "red")
      print("Can it appropriate?")
      ok<-scan(what = "character")}
    clust<-cutreeStatic(sampleTree, cutHeight = okline, minSize = 10)
    keepSamples<-(clust==1)
    FPKM<-FPKM[keepSamples,]
    print(table(clust))
    rm(sampleTree,okline,ok,clust,keepSamples)
    gc()}
  powers<-c(c(1:10), seq(from = 12, to=20, by=2))
  sft<-pickSoftThreshold(FPKM, powerVector = powers, verbose = 5,blockSize = mGene*1000)
  par(mfrow = c(1,2))
  plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],xlab="Soft Threshold (power)",ylab="Scale Free Topology Model Fit,signed R^2",type="n",main = paste("Scale independence"))
  text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],labels=powers,cex=0.9,col="red")
  abline(h=0.90,col="red")
  plot(sft$fitIndices[,1], sft$fitIndices[,5],xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n",main = paste("Mean connectivity"))
  text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powers, cex=0.9,col="red")
  okpower<-sft$powerEstimate
  print(paste("The power result is",okpower,". Need to modify ?"))
  judg<-scan(what = "character")
  if(judg=="yes"){
    print("Please input your okpower")
    okpower<-scan()
    print(paste("Now the power result is",okpower))}
  rm(sft,powers,judg)
  gc()
  net<-blockwiseModules(FPKM, power = okpower,TOMType = "unsigned", minModuleSize = minMD, reassignThreshold = 0,mergeCutHeight = 0.25,numericLabels = TRUE, pamRespectsDendro = FALSE,verbose = 3,maxBlockSize=mGene*1000)
  moduleColors<-labels2colors(net$colors)
  geneTree<-net$dendrograms[[1]]
  MEs<-orderMEs(moduleEigengenes(FPKM, moduleColors)$eigengenes)
  rm(net)
  gc()
  gc()
  if(Map){
    dissTOM<-1-TOMsimilarityFromExpr(FPKM, power = okpower)
    plotTOM<-dissTOM^7
    diag(plotTOM) = NA
    rm(dissTOM)
    gc()
    sizeGrWindow(9,9)
    TOMplot(plotTOM, geneTree, moduleColors, main = "Network heatmap of all modules")
    rm(plotTOM)}
  rm(geneTree)
  collectGarbage()
  gc()
  print("Now we can check some interesting target")
  Targetgene<-scan(what = "character",sep = ",")
  print(Targetgene)
  print(moduleColors[which(colnames(FPKM) %in% Targetgene)])
  write.csv(data.frame(Gene = Targetgene, Color = moduleColors[which(colnames(FPKM) %in% Targetgene)]),paste(Targetgene[1],"colorFrame.csv",sep = "_"),row.names = F)
  aa<-list(MEs,moduleColors,okpower,FPKM)
  rm(MEs,moduleColors,okpower,FPKM)
  gc()
  return(aa)}
## 8a03a29901b31176e32928321b1349e6
WGCNA_CliLink<-function(x,y,xais = T,yais = T){
  print("Now please enter one class name. Such as: Grade")
  class <- scan(what = "character")
  aa<-x[[1]][match(grep(class,rownames(x[[1]]),value = T),rownames(x[[1]])),match(rownames(y[[4]]),colnames(x[[1]]))]
  aa<-apply(aa, 1, as.numeric)
  TraitCor<-cor(y[[1]], aa, use = "p")
  TraitPvalue<-corPvalueStudent(TraitCor, nrow(y[[1]]))
  textMatrix<-paste(signif(TraitCor, 2), "\n(",signif(TraitPvalue, 1), ")", sep = "")
  dim(textMatrix) = dim(TraitCor)
  par(mar = c(6, 8.5, 3, 3))
  sizeGrWindow(10,6)
  if(xais){name = grep(class,rownames(x[[1]]),value = T)}else{name = NULL}
  if(yais){name2 = colnames(y[[1]])}else{name2 = NULL}
  labeledHeatmap(Matrix=TraitCor,xLabels = name,yLabels = name2,colorLabels = F,colors = blueWhiteRed(50),textMatrix = textMatrix,setStdMargins = FALSE,cex.text = 0.5,zlim = c(-1,1),main = paste("Module-trait relationships"))
  rm(TraitCor,TraitPvalue,textMatrix)
  a<-list(aa,substring(names(y[[1]]),3),x[[1]])
  rm(aa)
  print(a[[2]])
  gc()
  return(a)}
## 8a03a29901b31176e32928321b1349e6
WGCNA_Detail<-function(x,y,Cliorder=NULL,Trait=NULL,Color=NULL,Mapcolor=Color,MMCutgene=0.20,GSCutgene=0.20,Cys = T){
  weight<-as.data.frame(x[[1]][,Cliorder])
  names(weight)<-Trait
  Names<-substring(names(y[[1]]), 3)
  MM<-as.data.frame(cor(y[[4]], y[[1]], use = "p"))
  MMPvalue<-as.data.frame(corPvalueStudent(as.matrix(MM), nrow(y[[4]])))
  names(MM)<-paste("MM", Names, sep="");
  names(MMPvalue)<-paste("p.MM", Names, sep="")
  GS<-as.data.frame(cor(y[[4]], weight, use = "p"));
  GSPvalue<-as.data.frame(corPvalueStudent(as.matrix(GS), nrow(y[[4]])))
  names(GS)<-paste("GS.", names(weight), sep="");
  names(GSPvalue)<-paste("p.GS.", names(weight), sep="")
  column<-match(Color, Names)
  moduleGenes<-y[[2]]==Color
  sizeGrWindow(7, 7)
  par(mfrow = c(1,1))
  verboseScatterplot(abs(MM[moduleGenes, column]), abs(GS[moduleGenes, 1]),xlab = paste("Module Membership in", Color, "module"), ylab = paste("Gene significance for",Trait),abline = 1,abline.lty = 1,abline.color = Mapcolor,main = paste("Module membership vs. Gene significance\n"),cex.main = 1.2, cex.lab = 1.2, cex.axis = 1.2, col = Mapcolor)
  abline(h = GSCutgene, v = MMCutgene, col = "red")
  aa<-data.frame(MM=MM[moduleGenes, column],GS=GS[moduleGenes, 1],absMM=abs(MM[moduleGenes, column]),absGS=abs(GS[moduleGenes, 1]),row.names =rownames(GS)[moduleGenes])
  print("Now please enter the Dataclass name. Such as: LGG_FPKMUQ_mRNA")
  name<-scan(what = "character")
  write.csv(aa,paste(name,Trait,Color,"MMandGS.csv",sep = "_"))
  aa<-aa[which(aa[,3] > MMCutgene & aa[,4] > GSCutgene),]
  ac<-rownames(aa)
  rm(aa)
  ab<-rownames(GS)[moduleGenes]
  rm(Names,MM,MMPvalue,GS,GSPvalue,column,moduleGenes)
  gc()
  if(Cys){
    TOM<-TOMsimilarityFromExpr(y[[4]], power = y[[3]])
    inModule<-is.finite(match(y[[2]], Color))
    modGenes<-colnames(y[[4]])[inModule]
    modTOM<-TOM[inModule, inModule]
    dimnames(modTOM) = list(modGenes,modGenes)
    cyt<-exportNetworkToCytoscape(modTOM,edgeFile = paste(name,"edges", paste(Color), "Cys.txt", sep="_"),nodeFile = paste(name,"nodes", paste(Color), "Cys.txt", sep="_"),weighted = TRUE,threshold = 0.02, nodeNames = modGenes, nodeAttr = y[[2]][inModule])
    rm(TOM,inModule,modGenes,modTOM,cyt)
    gc()}
  rm(name)
  aa<-list(ac,ab,weight)
  rm(ac,ab,weight)
  print(aa[[1]])
  gc()
  return(aa)}
## 8a03a29901b31176e32928321b1349e6
WGCNA_Eigen<-function(x,y){
  MEs<-moduleEigengenes(y[[4]],y[[2]])$eigengenes
  MET = orderMEs(cbind(MEs, x[[3]]))
  rm(MEs)
  gc()
  sizeGrWindow(5,7.5)
  par(cex = 0.9)
  print("Eigengene dendrograme,ok?")
  ok<-scan()
  if(ok=="1")
  {plotEigengeneNetworks(MET, "Eigengene dendrogram", marDendro = c(0,4,2,0), plotHeatmaps = FALSE)}
  print("Eigengene adjacency heatmap,ok?")
  ok<-scan()
  if(ok=="1")
  {plotEigengeneNetworks(MET, "Eigengene adjacency heatmap", marHeatmap = c(3,4,2,2),plotDendrograms = FALSE, xLabelsAngle = 90)}
  print("Need compose?")
  ok<-scan()
  if(ok=="1")
  {plotEigengeneNetworks(MET, "", marDendro = c(0,4,1,2), marHeatmap = c(3,4,1,2), cex.lab = 0.8, xLabelsAngle= 90)}
  rm(MET)
  gc()}
## 8a03a29901b31176e32928321b1349e6
DESeq2<-function(countMatrix, pData){
  dds<-DESeqDataSetFromMatrix(countData = countMatrix, colData = pData, design = ~ phenotype)
  dds<-DESeq(dds)
  dds<-replaceOutliersWithTrimmedMean(dds)
  res<-results(dds, cooksCutoff=FALSE)
  rm(dds)
  res<-res[order(res$padj),]
  return(res)}
## 8a03a29901b31176e32928321b1349e6
DErun<-function(x,y,pvalue = 0.01,log2FC = 2,run = T,save = F){
  library(DESeq2)
  if(run){
    positive_ReadCount<-x
    negative_ReadCount<-y
    colnames(negative_ReadCount)<-paste("N",colnames(negative_ReadCount),sep="-")
    colnames(positive_ReadCount)<-paste("P",colnames(positive_ReadCount),sep="-")
    ReadCount<-cbind(negative_ReadCount,positive_ReadCount)
    ReadCount<-round(ReadCount)
    feature<-c(rep("Neg",ncol(negative_ReadCount)),rep("Pos",ncol(positive_ReadCount)))
    rm(positive_ReadCount,negative_ReadCount)
    gc()
    pData<-data.frame(phenotype = factor(feature,levels=c("Neg", "Pos")))
    rownames(pData)<-colnames(ReadCount)
    diffExp<-DESeq2(ReadCount,pData)
    if(save){
      print("Please enter the name you want to save. Such as: LGG_FPKMUQ_lncRNA_Grade")
      name<-scan(what = "character")
      write.csv(diffExp,paste(name,"padj.csv",sep = "_"))
      rm(name)}
    DEgene<-as.data.frame(diffExp)
    DEname<-rownames(DEgene[DEgene$padj<=pvalue & abs(DEgene$log2FoldChange)>=log2FC,])
    print(sort(DEname))
    rm(diffExp,ReadCount,pData)
    gc()}
  if(!run){
    print("Please enter the name you have saved.Such as: LGG_FPKMUQ_lncRNA")
    named<-scan(what = "character")
    DEgene<-read.csv(paste(named,"padj.csv",sep = "_"),header = T,row.names = 1)
    DEname<-rownames(DEgene[DEgene$padj<pvalue & abs(DEgene$log2FoldChange)>log2FC,])
    print(sort(DEname))
    rm(named)
    gc()}
  aa<-list(DEgene,DEname)
  rm(DEgene,DEname)
  gc()
  return(aa)}
## 8a03a29901b31176e32928321b1349e6
Display <- function(x,y = NULL,only = T,log2 = T,wid = 8,h = 5,yname = "Normalized expression(log2)",showGeom = T,Geomsize = 0.85){
  target <- y
  if(only){
    print("Please input your target.")
    target <- scan(what = "character")}
  Frame <- data.frame()
  for (i in 1:length(x)) {
    Frame1 <- as.numeric(x[[i]][rownames(x[[i]]) == target,])
    Frame2 <- rep(names(x)[i],length(Frame1))
    FrameT <- data.frame(Frame1,Frame2)
    rm(Frame1,Frame2)
    Frame<-rbind(Frame,FrameT)
    rm(FrameT)}
  FrameGet <- Frame[rowSums(Frame==0)==0,]
  rm(Frame)
  colnames(FrameGet)<-c("Exp","Status")
  if(log2){
    FrameGet[,3]<-log2(as.numeric(FrameGet[,1]))
    colnames(FrameGet)<-c("ExpTem","Status","Exp")}
  dev.set()
  if(showGeom)
  {ggplot(data = FrameGet,aes(x=Status,y=Exp,colour=Status))+geom_boxplot(aes(fill=Status),colour="black")+ggtitle(target)+xlab("status")+ylab(yname)+theme_bw()+theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),legend.title = element_blank())+theme(plot.title = element_text(hjust = 0.5))+geom_jitter(size=Geomsize,width = 0.07,colour="black")}
  else{ggplot(data = FrameGet,aes(x=Status,y=Exp,colour=Status))+geom_boxplot(aes(fill=Status),colour="black")+ggtitle(target)+xlab("status")+ylab(yname)+theme_bw()+theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),legend.title = element_blank())+theme(plot.title = element_text(hjust = 0.5))}
  ggsave(paste(gsub("/","-",target),"png",sep = "."),device = "png",width = wid,height = h)
  dev.off()}
## 8a03a29901b31176e32928321b1349e6
DEplot<-function(x, pvalue = 0.01, log2FC = 2, plimit = 30, log2limit = 5, color = 3){
  x$Legend<-as.factor(ifelse(x$padj<pvalue & abs(x$log2FoldChange)>=log2FC, ifelse(x$log2FoldChange>log2FC,'Up','Down'),'Not'))
  print("Please enter your Title name")
  Title<-scan(what = "character",sep = ",")
  if(color == 3){colornum <- c("blue", "black", "red")}
  if(color == 2){colornum <- c("black", "red")}
  ggplot(data=x,aes(x=log2FoldChange, y=-log10(padj),colour=Legend))+ggtitle(Title)+xlab("log2 Foldchange")+ylab("-log10 Padj")+geom_vline(xintercept=c(-log2FC,log2FC),lty=6,col="grey",lwd=0.5)+geom_hline(yintercept = -log10(pvalue),lty=4,col="grey",lwd=0.5)+scale_color_manual(values = colornum)+theme(legend.position="right")+theme_bw()+theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),legend.title = element_blank())+xlim(-log2limit,log2limit) + ylim(0,plimit)+theme(plot.title = element_text(hjust = 0.5))+geom_point(alpha=0.4, size=1.2)}
## 8a03a29901b31176e32928321b1349e6
Surplot<-function(x,y,method = "mean",Stime = "3000"){
  TestFrame <- data.frame(y[c(1,2,x+3,3),which(!y[x+3,]==0)])
  if(method == "mean"){TestFrame[3,ncol(TestFrame)+1] <- mean(as.numeric(TestFrame[3,]))}
  if(method == "median"){TestFrame[3,ncol(TestFrame)+1] <- median(as.numeric(TestFrame[3,]))}
  if(method == "Custom"){
    print(rownames(TestFrame)[3])
    print("Please insert the Cutoff value. Such as: 100 ")
    TestFrame[3,ncol(TestFrame)+1] <- as.numeric(scan())}
  RocFrame <- TestFrame[c(4,3),-ncol(TestFrame)]
  RocFrame[1,which(RocFrame[1,]=="1")] <- 0
  RocFrame[1,which(RocFrame[1,]=="2")] <- 1
# RocFrame[1,which(RocFrame[1,]=="2")] <- 0
# RocFrame[1,which(RocFrame[1,]=="3")] <- 0 
# RocFrame[1,which(RocFrame[1,]=="4")] <- 1
  write.csv(t(RocFrame),paste("ROC",x,".csv",sep = ""))
  AUC <- as.numeric(roc(as.numeric(RocFrame[1,]),as.numeric(RocFrame[2,]),plot = T)$auc)
  print(AUC)
  rm(RocFrame,AUC)
  TestFrame[3,which(TestFrame[3,] < TestFrame[3,ncol(TestFrame)])] <- 0
  TestFrame[3,which(TestFrame[3,] >= TestFrame[3,ncol(TestFrame)])] <- 1
  print(table(as.character(TestFrame[4,which(TestFrame[3,]==0)])))
  print(table(as.character(TestFrame[4,which(TestFrame[3,]==1)])))
  TestFrame <- TestFrame[-nrow(TestFrame),-ncol(TestFrame)]
  TestFrame <- apply(TestFrame, 1, as.numeric)
  TestFrame <- as.data.frame(TestFrame)
  fit <- survfit(Surv(TestFrame[,1], TestFrame[,2]) ~ TestFrame[,3], data = TestFrame)
  ggsurvplot(fit,pval = TRUE,xlab = "Time in days",legend.labs = c("Low", "High"),xlim = c(0,Stime),break.time.by = 600,legend.title = element_blank(),risk.table = TRUE,surv.median.line = "hv",palette = c("blue", "red"),ggtheme = theme_light())+ggtitle(colnames(TestFrame)[3])
  }
## 8a03a29901b31176e32928321b1349e6
Survi<-function(x){
  SurEnd <- data.frame(Target = c(1:nrow(x)),Sur_P = c(1:nrow(x)))
  for (i in 1:length(Targetname)) {
    TestFrame <- x[c(1,2,i+2),which(!x[i+2,]==0)]
    TestFrame[3,ncol(TestFrame)+1] <- mean(as.numeric(TestFrame[3,]))
    TestFrame[3,which(TestFrame[3,] < TestFrame[3,ncol(TestFrame)])] <- "1"
    TestFrame[3,which(TestFrame[3,] >= TestFrame[3,ncol(TestFrame)])] <- "2"
    TestFrame <- TestFrame[,-ncol(TestFrame)]
    TestFrame <- apply(TestFrame, 1, as.numeric)
    TestFrame <- as.data.frame(TestFrame)
    diff <- survdiff(Surv(TestFrame[,1],TestFrame[,2]) ~ TestFrame[,3], data = TestFrame)
    pval <- 1 - pchisq(diff$chisq, length(diff$n) - 1)
    SurEnd[i,1] <- colnames(TestFrame)[3]
    SurEnd[i,2] <- pval}
  rm(diff,pval)
  print("Please input your Survi name.")
  name<-scan(what = "character")
  write.csv(SurEnd,paste("Sur",name,".csv",sep = "_"))
  rm(name)
  return(SurEnd)}
## 8a03a29901b31176e32928321b1349e6
Enrich <- function(x,Cut = 0.01,Go = T,Kegg = T,Keggmap = T,save = T,Gomap = T,wid = 8, h = 5){
  library(clusterProfiler)
  GeneID <- bitr(x,fromType = "SYMBOL",toType = "ENTREZID",OrgDb = "org.Hs.eg.db")
  ac<-NULL
  bc<-NULL
  if(save){
    print("Please enter the name to save GeneID. Such as: LGG_FPKMUQ_mRNA")
    IDname <- scan(what = "character",sep = ",")
    write.csv(GeneID,paste(IDname,"GeneID.csv",sep = "_"))}
  gc()
  if(Go){
    ab <- enrichGO(gene =as.character(GeneID[,2]),OrgDb="org.Hs.eg.db",ont = "ALL",pAdjustMethod = "BH",minGSSize = 1,pvalueCutoff = Cut,qvalueCutoff = Cut,readable = TRUE)
    aa <- data.frame(ab)
    rm(ab)
    gc()
    if(save){write.csv(aa,paste(IDname,"GO_enrichment.csv",sep = "_"))}
    ac <- aa[c(which(aa$ONTOLOGY=="BP")[1:10], which(aa$ONTOLOGY=="CC")[1:10], which(aa$ONTOLOGY=="MF")[1:10]),]
    rm(aa)
    gc()
    ac <- na.omit(ac)
    if(Gomap){
      library(ggplot2)
      dev.set()
      ggplot(data=ac,aes(ac$Count/length(as.character(GeneID[,2])),ac$Description))+geom_point(aes(size=ac$Count,color=-1*log10(ac$qvalue),shape=ac$ONTOLOGY))+scale_colour_gradient(low="blue",high="red")+labs(color=expression(-log[10](Qvalue)),size="Gene number",shape="Ontology",x="GeneRatio",y=NULL,title="GO enrichment")+theme_bw()+theme(plot.title = element_text(hjust = 0.5))
      if(save){ggsave(paste(IDname,"png",sep = "."),device = "png",width = wid,height = h)}
      dev.off()}
    gc()}
  if(Kegg){
    bb <- enrichKEGG(gene = as.character(GeneID[,2]),organism = "human",qvalueCutoff = Cut)
    bc <- data.frame(bb)
    rm(bb)
    gc()
    for (i in 1:nrow(bc)) 
      {bc[i,ncol(bc)+1]<-paste(as.character(GeneID[,1])[GeneID[,2] %in% strsplit(bc$geneID,"/")[[i]]],collapse = "/")}
    if(save)
    {write.csv(bc,paste(IDname,"KEGG_enrichment.csv",sep = "_"))
      rm(IDname)}
    if(Keggmap){
      library(pathview)
      pathview(gene.data = as.character(GeneID[,2]),pathway.id = bc$ID,species = "hsa")}}
  rm(GeneID)
  aa<-list(ac,bc)
  rm(ac,bc)
  gc()
  gc()
  return(aa)}
## 8a03a29901b31176e32928321b1349e6
Datamer <- function(x,type = "FPKM-UQ",save = F){
  folders <- list.files(x)
  files <- list.files(paste(x,folders[1],sep = ""))
  files_gz <- files[grepl(type,files)]
  data <- read.table(gzfile(paste(x,folders[1],"/",files_gz,sep = "")))
  names(data) <- c("ENSG_ID",gsub("\\..*", "",files_gz))
  for (fd in folders[2:length(folders)]) {
    files <- list.files(paste(x,fd,sep = ""))
    files_gz <- files[grepl(type,files)]
    mydata <- read.table(gzfile(paste(x,"/",fd,"/",files_gz,sep = "")))
    names(mydata) = c("ENSG_ID",gsub("\\..*", "",files_gz))
    data <- merge(data,mydata,by = "ENSG_ID")
    rm(mydata,files,files_gz)
    gc()}
  rownames(data) <- gsub("\\..*","",data[,1])
  data <- data[,-1]
  if(save)
  {print("Please input the name you want to save. Such as: LGG_FPKMUQ_mRNA")
    name<-scan(what = "character")
    write.csv(data,paste(name,"merge.csv",sep = "_"))
    rm(name)}
  rm(folders)
  gc()
  return(data)}
## 8a03a29901b31176e32928321b1349e6
## Link 18746004617. ##